
# Todo : 

- Je me demande si le Bot ne pourrais pas etre générique , il n'y a que son nom, id, port, et System de Trading qui sont spécialisé et les paramétres par défaut
- Mieux gérer les status du serveur http et du bot en retour des commande http
- Lancer les bt et train en mode asynchrone et vernir récupérer le dernier résultat via un autre endpoint
``` /last_backtest ou last_trainnig ```
- Lancer le bt et train dans un vrai thread


- BUG : Pour le random bot le backtest renvoi un total profit démesuré 8000
- Faire un end point /info qui renvoi les paramétres (et les dernière stats)


# Doing : 
- BUG : A priori aucun trade pendant 20 miniutes , ça me semble bizarre.
- Tester avec  un autre bot = Randdom bot

# Done : 
- implémenter la methode /stop
- implémenter la méthode /start