def test_one_equals_one():
    assert 1 == 1