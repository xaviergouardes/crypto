# Strétégie Slope
Stratégie basée sur la pente d'une moyenne mobile.
Avec u nrisque manager basé sur ATR

# Run
| actif   | period | ema_slow | ema_fast |  buffer_size | slope_threshold | loopback| history_window | risk | tp    | sl    | win rate | p&l final |
| ethusdc |   5m   | 21       | 7        |  2           | 0               |    5    |      21        | fixe | 2     | 1.25  | 55.26    | 850       |

