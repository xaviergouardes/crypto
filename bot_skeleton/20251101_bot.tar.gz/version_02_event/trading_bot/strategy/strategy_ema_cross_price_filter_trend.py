from datetime import datetime

from collections import deque
from trading_bot.core.event_bus import EventBus
from trading_bot.core.events import TradeSignalGenerated, IndicatorUpdated, CandleClose, PriceUpdated


class StrategyEmaCrossPriceFilterTrendsEngine:
    """
    Stratégie : génère des signaux selon le croisement des prix avec l'EMA
    """

    def __init__(self, event_bus: EventBus,
                 ema_trend_period="200",
                 ema_band_with=0.001
                 ):
        self.ema_trend_period = ema_trend_period
        self.ema_band_with = ema_band_with

        self.event_bus = event_bus

        self.entry_price = None
        self.ema = None
        self.candle = None
        self.ema_trend = None

        # Flags pour savoir si on a reçu au moins un événement de chaque type
        self.received_indicator = False
        self.received_candle = False
        self.received_price = False

        # Abonnement aux SMA des chandelles
        self.event_bus.subscribe(IndicatorUpdated, self.on_indicator_update)
        self.event_bus.subscribe(CandleClose, self.on_candle_close)
        self.event_bus.subscribe(PriceUpdated, self.on_price_update)

        print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [StrategyEmaCrossPriceFilterTrendsEngine] Initialisation Terminée ema_trend_period={self.ema_trend_period} / ema_band_with={self.ema_band_with}")

    async def on_price_update(self, event: PriceUpdated) -> None:
        """Réception d'un nouveau prix."""
        self.entry_price = event.price
        self.received_price = True

    async def on_indicator_update(self, event: IndicatorUpdated):
        ema_value = event.values.get("ema_candle")
        ema_period = event.values.get("ema_candle_period")

        if ema_value is not None and ema_period==self.ema_trend_period:
            self.ema_trend = ema_value

        if ema_value is not None and ema_period!=self.ema_trend_period:
            self.ema = ema_value

        self.received_indicator = True

    async def on_candle_close(self, event: CandleClose):
        self.candle = event.candle
        self.received_candle = True
        await self.evaluate_strategy()


    async def evaluate_strategy(self):
        #print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [StrategyEmaCrossPriceEngine] Evaluer la stratégie")

        # On ne calcule un signal que si tous les deux  événements ont été reçus au moins une fois
        if not (self.received_price and self.received_candle and self.received_indicator):
            print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [StrategyEmaCrossPriceEngine] Pas assez de données pour évaluer la stratégie")
            return

        signal = None

        # Déterminer le type de bougie
        bullish = self.candle.close > self.candle.open
        bearish = self.candle.close < self.candle.open
        
        o, c = self.candle.open, self.candle.close
        h, l = self.candle.high, self.candle.low
        # c1, c2 = data[t-1]['close'], data[t-2]['close']
        # e, e1, e2 = ema[t], ema[t-1], ema[t-2]

        corps = abs(c - o)
        taille_bougie = h - l

        # Corps >= 2/3 de la bougie
        seuil_corps = 1/3
        grand_corps = taille_bougie > 0 and (corps >= seuil_corps * taille_bougie)

        # Calcul des mèches
        meche_haute = h - max(o, c)
        meche_basse = min(o, c) - l

        # marge relative autour de l'EMA (par exemple 0.1%)
        # buffer = self.ema * 0.0005  # 0.1% autour de l'EMA
        buffer = self.ema * self.ema_band_with  # 0.1% autour de l'EMA

        ema_high_band = self.ema + buffer
        ema_low_band = self.ema - buffer

        cross_up = self.candle.close > ema_high_band and self.candle.open < ema_low_band
        cross_down = self.candle.close < ema_low_band and self.candle.open > ema_high_band

        # print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [StrategyEmaCrossPriceEngine] bullish={bullish} / bearish={bearish} / open={self.candle.open} / close={self.candle.close} / ema={self.ema}")
        # print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [StrategyEmaCrossPriceEngine] grand_corps {grand_corps} / "
        #       f"meche_haute {meche_haute} / "
        #       f"meche_basse {meche_basse} / "
        #       f"cross_up {cross_up} / "
        #       f"cross_down {cross_down}")
        # Conditions de signal
        if cross_down and (grand_corps and (meche_haute > meche_basse) ):
            signal = "SELL"
        elif cross_up and (grand_corps and (meche_basse > meche_haute) ):
            signal = "BUY"
        else:
            # print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [StrategyEmaCrossPriceEngine] Signal {signal} / {self.candle} / {self.ema}")
            return
        
        # filtre trend
        bearish_trend = self.candle.close < self.ema_trend 
        bullish_trend = self.candle.close > self.ema_trend 

        if signal == "SELL" and bullish_trend: return
        if signal =="BUY" and bearish_trend: return


        # print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [StrategyEmaCrossPriceEngine] Signal {signal} / {self.candle} / {self.ema}")
        if signal:
            await self.event_bus.publish(TradeSignalGenerated(
                side=signal,
                confidence=1.0,
                price=self.entry_price,
                strategie = self.__class__.__name__,
                strategie_parameters = {
                    "ema_trend_period": self.ema_trend_period,
                    "ema_band_with": self.ema_band_with,                    
                },
                strategie_values = {
                    "cross_down": cross_down,
                    "cross_up": cross_up,
                    "grand_corps": grand_corps,
                    "meche_basse": meche_basse,
                    "meche_haute": meche_haute, 
                    "ema": self.ema,
                    "ema_high_band": ema_high_band,
                    "ema_low_band": ema_low_band,
                    "candle": self.candle,
                    "ema_trend": self.ema_trend,
                    "bearish_trend": bearish_trend,
                    "bullish_trend": bullish_trend
                }, 
            ))

        self.received_indicator = False
        self.received_candle = False
        self.received_price = False

    async def run(self):
        """Rien à faire ici : tout est événementiel."""
        pass
