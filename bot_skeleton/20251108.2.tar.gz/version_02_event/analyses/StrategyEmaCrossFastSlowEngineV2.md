# Strétégie Slope
Stratégie basée sur la pente d'une moyenne mobile.
Avec u nrisque manager basé sur ATR

# Run
| actif   | period | ema_slow | ema_fast |  windows | slope_threshold | risk | tp    | sl    | win rate | p&l final |
| ethusdc |   5m   | 100      | 21       |  2       | 3.25            | atr  | 2x    | 1.25x | 54.166   | 237       |
| ethusdc |   5m   | 100      | 21       |  2       | 3.25            | atr  | 1.5x  | 1.0x  | 54.166   | 145       |
| ethusdc |   5m   | 200      | 21       |  2       | 3.5             | atr  | 2x    | 1.25x | 61.111   | 275       |
