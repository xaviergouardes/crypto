# Strétégie Slope
Stratégie basée sur la pente d'une moyenne mobile.
Avec u nrisque manager basé sur ATR

# Run
| actif   | period | ema | windows | threshold | risk | tp  | sl  | win rate | p&l final |
| ethusdc |   5m   | 30  | 3       |  4.5      | atr  | 3   | 2.5 | 55.55    | 185.99    |
| ethusdc |   5m   | 30  | 3       |  4.5      | atr  | 4   | 3   | 59.37    | 424.71    |
